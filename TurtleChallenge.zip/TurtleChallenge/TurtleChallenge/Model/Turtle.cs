﻿using System;
using System.Collections.Generic;

namespace TurtleChallenge.Model
{
    public class Turtle
    {
        public int CurrentRow { get; private set; }
        public int CurrentColumn { get; private set; }

        private Direction _currentDirection;

        private readonly Dictionary<Direction, DirectionWeights> _directionWeightMap;
        private readonly Dictionary<string, Direction> _directions;
        private  Point _point = new Point();
        
        public Turtle(string orientation, int rowPosition, int columnPosition)
        {
            _directions = new Dictionary<string, Direction>
            {
                { "N", Direction.North }, { "S", Direction.South },
                { "W", Direction.West }, { "E", Direction.East }
            };

            _directionWeightMap = new Dictionary<Direction, DirectionWeights>
            {
                { Direction.North, new DirectionWeights { Row = -1, Column = 0 } },
                { Direction.East,  new DirectionWeights { Row = 0, Column = 1 } },
                { Direction.South, new DirectionWeights { Row = 1, Column = 0 } },
                { Direction.West,  new DirectionWeights { Row = 0, Column = -1 } },
            };

            CurrentRow = rowPosition;
            CurrentColumn = columnPosition;
            SetOrientation(orientation);
        }

        public void RotateRight()
        {
            switch (_currentDirection)
            {
                case Direction.North:
                    _currentDirection = Direction.East;
                    break;
                case Direction.South:
                    _currentDirection = Direction.West;
                    break;
                case Direction.East:
                    _currentDirection = Direction.South;
                    break;
                case Direction.West:
                    _currentDirection = Direction.North;
                    break;
                default:
                    break;
            }
        }

        public void RotateLeft()
        {
            switch (_currentDirection)
            {
                case Direction.North:
                    _currentDirection = Direction.West;
                    break;
                case Direction.South:
                    _currentDirection = Direction.East;
                    break;
                case Direction.East:
                    _currentDirection = Direction.North;
                    break;
                case Direction.West:
                    _currentDirection = Direction.South;
                    break;
                default:
                    break;
            }
        }

        public void SetOrientation(string direction)
        {
            var key = direction.ToUpper();

            if (!_directions.ContainsKey(key))
                throw new ArgumentException(key);

            _currentDirection = _directions[key];
        }
        
        public Point Move()
        {
            var position = ComputeNextDirectionWeights(_currentDirection, CurrentRow, CurrentColumn);

            CurrentRow = position.Row;
            CurrentColumn = position.Column;

            _point.X = CurrentColumn;
            _point.Y = CurrentRow;
            return _point;
        }

        private DirectionWeights ComputeNextDirectionWeights(Direction currentDirection, int row, int column)
        {
            if (!_directionWeightMap.ContainsKey(currentDirection))
                throw new ArgumentException(nameof(currentDirection));
            var weights = _directionWeightMap[currentDirection];
            weights.Row += row;
            weights.Column += column;
            return weights;
        }

        private struct DirectionWeights
        {
            public int Row { get; set; }
            public int Column { get; set; }
        }
    }
}
