﻿using System;
using System.Threading;
using TurtleChallenge.Settings;

namespace TurtleChallenge.Model
{
    public class GameSettings
    {
        private static string InitialDirection = "";
        private static int NoOfRows = 0;
        private static int NoOfColumns = 0;
        static int[,] board;
        static int StartX = 0;
        static int StartY = 0;
        public int ExitX = 0;
        public int ExitY = 0;
        private SettingsReader _reader;
        Point _point = new Point();
        Point _exit = new Point();

        public void ReadGameSettings(string fileName)
        {
            try
            {

                _reader = new SettingsReader(fileName);
                if (_reader.values != null)
                {
                    DisplayMessageOnANewLine("Welcome to Escape Mines Turtle Challenge Assignment By:=");
                    DisplayMessageOnANewLine("***************************************************************************");
                    DisplayMessageOnANewLine("*             CHUKWUMA PRECIOUS CHUKWUEKU                                 *");
                    DisplayMessageOnANewLine("***************************************************************************");

                    /*
                    Note: To Get accurate result, Kindly enter the values in the order of 
                    X and Y respectively as we assume and assign first value to X and second to Y             
                    */

                    string boardSettings = _reader.BoardSetting();
                    UpdateBoardSettings(boardSettings);   // read board settings
                    string Tile = _reader.TileSetting();    // X and Y order.
                    string Exit = _reader.ExitSetting();
                    ComputExit(Exit); // initializr the exit point   
                    string Start = _reader.StartSetting();
                    ComputStartPoint(Start);  // initialize the start point 

                    var game = new Game(new Turtle(InitialDirection, StartY, StartX));

                    _exit.X = ExitX;
                    _exit.Y = ExitY;

                    var seqq = _reader.ReadSequences();
                    int coutnter = 0;
                    foreach (var item in seqq)
                    {
                        var sequence = SplitString(item, ' ');
                        foreach (var t in sequence)
                        {
                            if (!string.IsNullOrEmpty(t))
                            {
                                _point = game.Execute(t);
                            }
                        }
                        coutnter++;
                        Console.Write($"Sequence {coutnter}: ");
                        ObserveState(_point, _exit, Tile);
                        game = new Game(new Turtle(InitialDirection, StartY, StartX));  // reinitialize the start point and initial direction
                        Thread.Sleep(1000);
                    }
                }
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                string log = ex.Message;
                Console.WriteLine("An Exception has Occured. Please refer to the readme file.");
                Console.ReadLine();
            }
        }      

        public void ObserveState(Point _point, Point _exit, string tile)
        {
            var status = ObserveStatus(_point, _exit, tile);
            if (status == Status.IsExit)
                Message.PrintIsSuccess();
            else if (status == Status.IsMineHit)
                Message.PrintIsMineHit();
            else if (status == Status.IsInDanger)
                Message.PrintIsDanger();

        }

        public void UpdateBoardSettings(string boardsettings)
        {

            var spt = SplitString(boardsettings, ' ');
            NoOfColumns = Convert.ToInt16(spt[0]);  // reads value for X
            NoOfRows = Convert.ToInt16(spt[1]);     // reads value for Y           
            board = CreateTwoDimensionArray(NoOfRows, NoOfColumns);
        }
        public void ComputStartPoint(string startpoint)
        {
            var x = startpoint.Split(' ');
            StartX = Convert.ToInt32(x[0]);
            StartY = Convert.ToInt32(x[1]);
            InitialDirection = (x[2]);
        }
        public void ComputExit(string exit)
        {
            var x = exit.Split(' ');
            ExitX = Convert.ToInt32(x[0]);
            ExitY = Convert.ToInt32(x[1]);
        }
       static int[,] CreateTwoDimensionArray(int row, int column)
        {
            int[,] array = new int[row, column];
            return array;
        }

        static void DisplayMessageOnANewLine(string message)
        {
            Console.WriteLine(message);
        }

        static string[] SplitString(string word, char splitKey)
        {
            return word.Split(splitKey);
        }

        public static Status ObserveStatus(Point position, Point Exit, string Mines)
        {
            if (IsMineHit(position, Mines))
                return Status.IsMineHit;          
            else if (IsSuccess(position, Exit))
                return Status.IsExit;
            else
                return Status.IsInDanger;
        }

        private static bool IsMineHit(Point position, string mine)
        {
            var p = $"{position.X},{position.Y}";
            var val = string.Empty;
            var lst = SplitString(mine, ' ');
            
            for(int i =0; i<lst.Length; i++)
            {
                if (p == lst[i])
                    return true;
            }   
            return false;
        }        
        private static bool IsSuccess(Point position, Point Exit)
        {
            if (position.X == Exit.X && position.Y == Exit.Y)
                return true;
            return false;
        }
    }
}
