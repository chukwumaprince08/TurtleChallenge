﻿using System;

namespace TurtleChallenge.Model
{
    public class Game
    {
        private readonly Turtle _turtle;
        private Point _point;
        

        public Game(Turtle turtle)
        {
            _turtle = turtle;
        }

        public Point Execute(string instruction)
        {
            switch (instruction.ToUpper())
            {
                case "M":
                   _point = _turtle.Move();
                    break;
                case "L":
                    _turtle.RotateLeft();
                    break;
                case "R":
                    _turtle.RotateRight();
                    break;
                default:
                    throw new ArgumentException(instruction);
            }
            _point.X = _turtle.CurrentColumn;
            _point.Y = _turtle.CurrentRow;
            return _point;
        }
    }
}
