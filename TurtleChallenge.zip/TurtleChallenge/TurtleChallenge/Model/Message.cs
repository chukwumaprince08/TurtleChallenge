﻿using System;

namespace TurtleChallenge.Model
{
    public static class Message
    {
    
        static string text = string.Empty;
        public static void PrintIsDanger()
        {
            text = "Still in Danger!";            
            Console.WriteLine(text);
        }

        public static void PrintIsSuccess()
        {
            text = "Success!";
            Console.WriteLine(text);
        }

        public static void PrintIsMineHit()
        {
            text = "Mine Hit!";
            Console.WriteLine(text);
        }
    }
}
