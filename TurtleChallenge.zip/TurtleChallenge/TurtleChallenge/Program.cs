﻿using System;
using TurtleChallenge.Model;

namespace TurtleChallenge
{
    public static class Program
    {  
        static void Main(string[] args)
        {
            Console.WriteLine("Enter name of the game settings file e.g game-settings");
            string settings = Console.ReadLine();

            if (!string.IsNullOrEmpty(settings))
            {              
                var g = new GameSettings();
                g.ReadGameSettings(settings);
            }
             
        }
    }
}
