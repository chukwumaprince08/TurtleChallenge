﻿To test this application, Kindly run the application and enter the text game-settings and press enter, 
this will run the application with the initial settings in the game settings file, as described in the Question booklet as attached.


Please note that all values are entered in the order of X and Y respectively
Kindly enter value for X followed by Y ex 4 2 
in the case above, 4 is a value for X coordinate, while 2 is a value for Y coordinate