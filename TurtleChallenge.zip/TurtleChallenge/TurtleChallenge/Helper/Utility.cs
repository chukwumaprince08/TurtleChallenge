﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurtleChallenge.Helper
{
    public class Utility
    {
        public string[] SplitString(string word, char splitKey)
        {
            return word.Split(splitKey);
        }
    }
}
