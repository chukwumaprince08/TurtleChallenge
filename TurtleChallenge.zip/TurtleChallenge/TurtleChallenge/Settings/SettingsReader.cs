﻿using System;
using System.Collections.Generic;
using System.IO;

namespace TurtleChallenge.Settings
{
    public class SettingsReader
    {   
        public string[] values;
        List<string> Mines = new List<string>();

        public SettingsReader(string fileName)
        {
            try
            {              
                values = File.ReadAllLines($"..\\..\\Files\\{fileName}");
            }
            catch (Exception)
            {
                Console.WriteLine("Sorry, we are unable to locate the file you specified. Kindly verify that the file exist in the files folder.");
            }
        }        
        
        public string BoardSetting()
        {           
            var size = values[0];  
            return size;
        }

        public string StartSetting()
        {
            var start = values[1];
            return start;
        }

        public string ExitSetting()
        {
            var exit = values[2];
            return exit;
        }

        public string TileSetting()
        {
            var tile = values[3];
            return tile;
        }

        public List<string> ReadSequences()
        {
            for(int i =4; i< values.Length; i++)
            {
                Mines.Add(values[i]);   
            }
            return Mines;
        }
    }
}
