﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TurtleChallenge.Model;

namespace TurtleChallenge.Tests
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestPoints()
        {
            Point point = new Point(2, 5);
            Assert.AreEqual(2, point.X);
        }

        [TestMethod]
        public void TestTurtleCanMove()
        {
            string InitialPosition = "N";
            int startX = 1;
            int startY = 1;
            var t = new Turtle(InitialPosition, startY, startX);
            Assert.AreEqual(startX, t.CurrentColumn);
            Assert.AreEqual(startY, t.CurrentRow);
        }

        [TestMethod]
        public void CanReadGameSettings()
        {
            string gamesettings = "game-settings";            
            Assert.IsNotNull(gamesettings);
            Assert.AreNotEqual(gamesettings, "game-setting");
        }

        [TestMethod]
        public void StatusIsCorrect()
        {
            Assert.AreNotSame(Status.IsInDanger, Status.IsMineHit);
        }       

    }
}
